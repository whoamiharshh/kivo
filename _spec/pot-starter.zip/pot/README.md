# Pot — shared money for friend groups (Monad Metropolis, Track 2)

Everyone adds money to one pot. The pot repays whoever paid for group costs,
under rules the group sets. When the pot closes, leftover money goes back to
each person in proportion to what they put in. Nobody has to hold the group's money.

> Hackathon build: runs on Monad Testnet with **test money only** (Test Rupee).

## Structure
- `contracts/` — Solidity (Foundry): `TestRupee.sol`, `PotManager.sol`, tests, deploy script
- `app/` — Next.js app (built with Claude Code, see `CLAUDE.md`)

## Run the contracts
```bash
curl -L https://foundry.paradigm.xyz | bash && foundryup   # install Foundry
cd contracts
git init   # only if this folder is not already inside a git repo
forge install foundry-rs/forge-std OpenZeppelin/openzeppelin-contracts
forge test -vv
```

## Deploy (Monad Testnet, chain 10143)
```bash
cast wallet import pot-dev --interactive        # paste a NEW testnet-only key
forge script script/Deploy.s.sol --rpc-url monad_testnet --account pot-dev --broadcast
```
Get testnet MON for deploy gas from the Monad faucet.

## Deployed addresses
- TestRupee: _TBD_
- PotManager: _TBD_

## Status (keep honest)
| Feature | Status |
|---|---|
| Contracts + tests | written, not yet compiled |
| Testnet deploy | not done |
| App | not started |
| User testing | not done |
