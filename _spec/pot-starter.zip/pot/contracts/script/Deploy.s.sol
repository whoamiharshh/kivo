// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {Script, console} from "forge-std/Script.sol";
import {TestRupee} from "../src/TestRupee.sol";
import {PotManager} from "../src/PotManager.sol";

contract Deploy is Script {
    function run() external {
        vm.startBroadcast();
        TestRupee token = new TestRupee();
        PotManager mgr = new PotManager(token);
        vm.stopBroadcast();
        console.log("TestRupee:", address(token));
        console.log("PotManager:", address(mgr));
    }
}
